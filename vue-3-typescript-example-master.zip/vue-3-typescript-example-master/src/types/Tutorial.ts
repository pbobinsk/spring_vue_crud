export default interface Tutorial {
  id: null;
  title: string;
  description: string;
  published: boolean;
}