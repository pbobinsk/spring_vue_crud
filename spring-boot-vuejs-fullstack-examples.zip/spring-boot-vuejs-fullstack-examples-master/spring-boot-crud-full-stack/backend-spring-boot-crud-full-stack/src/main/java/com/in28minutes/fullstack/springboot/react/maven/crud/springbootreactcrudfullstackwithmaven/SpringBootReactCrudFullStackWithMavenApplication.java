package com.in28minutes.fullstack.springboot.react.maven.crud.springbootreactcrudfullstackwithmaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootReactCrudFullStackWithMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReactCrudFullStackWithMavenApplication.class, args);
	}

}
